const DetailThread = require('../../../Domains/threads/entities/DetailThread')
const ThreadRepository = require('../../../Domains/threads/ThreadRepository');
const CommentRepository = require('../../../Domains/comments/CommentRepository');
const ReplyRepository = require('../../../Domains/replies/ReplyRepository');

const DetailThreadUseCase = require('../DetailThreadUseCase');

describe('DetailThreadUseCase', () => {
  it('should orchestrating the detail action correctly', async () => {
    // Arrange
    const id = 'thread-123';

    // Mocking
    const mockResult = {
      id: 'thread-123',
      title: 'sebuah thread',
      body: 'sebuah body thread',
      date: '2021-08-08T07:22:33.555Z',
      username: 'dicoding',
      comments: [
        {
          id: 'comment-123',
          username: 'dicoding',
          date: '2021-08-10T07:59:57.000Z',
          content: 'sebuah comment',
          replies: [
            {
              id: 'reply-123',
              content: 'sebuah reply',
              date: '2021-08-11T07:59:57.000Z',
              username: 'dicoding',
            }
          ],
        },
      ],
    };

    const mockDetailThread = new DetailThread({
      id: 'thread-123',
      title: 'sebuah thread',
      body: 'sebuah body thread',
      date: '2021-08-08T07:22:33.555Z',
      username: 'dicoding',
    });

    const mockDetailComment = [
      {
        id: 'comment-123',
        username: 'dicoding',
        date: '2021-08-10T07:59:57.000Z',
        content: 'sebuah comment',
        is_deleted: false,
      },
    ];

    const mockDetailReply = [
      {
        id: 'reply-123',
        content: 'sebuah reply',
        date: '2021-08-11T07:59:57.000Z',
        username: 'dicoding',
        is_deleted: false,
        comment_id: 'comment-123',
      },
    ];

    const mockThreadRepository = new ThreadRepository();
    const mockCommentRepository = new CommentRepository();
    const mockReplyRepository = new ReplyRepository();

    mockThreadRepository.getThreadById = jest.fn()
      .mockImplementation(() => Promise.resolve(mockDetailThread));
    mockCommentRepository.getAllCommentsByThreadId = jest.fn()
      .mockImplementation(() => Promise.resolve(mockDetailComment));
    mockReplyRepository.getAllRepliesByThreadId = jest.fn()
      .mockImplementation(() => Promise.resolve(mockDetailReply));  
    
    const getThreadUseCase = new DetailThreadUseCase({
      threadRepository: mockThreadRepository,
      commentRepository: mockCommentRepository,
      replyRepository: mockReplyRepository,
    });

    // Action
    const detailThread = await getThreadUseCase.execute(id);

    // Assert
    expect(detailThread).toStrictEqual(mockResult);
    expect(mockThreadRepository.getThreadById)
      .toBeCalledWith(id);
    expect(mockCommentRepository.getAllCommentsByThreadId)
      .toBeCalledWith(id);
    expect(mockReplyRepository.getAllRepliesByThreadId)
      .toBeCalledWith(id);
  });

  it('should not display comments or reply if comment or reply is deleted and orchestrating the detail action correctly', async () => {
    // Arrange
    const id = 'thread-123';

    // Mocking
    const mockResult = {
      id: 'thread-123',
      title: 'sebuah thread',
      body: 'sebuah body thread',
      date: '2021-08-08T07:22:33.555Z',
      username: 'dicoding',
      comments: [
        {
          id: 'comment-123',
          username: 'dicoding',
          date: '2021-08-10T07:59:57.000Z',
          content: '**komentar telah dihapus**',
          replies: [
            {
              id: 'reply-123',
              content: '**balasan telah dihapus**',
              date: '2021-08-11T07:59:57.000Z',
              username: 'dicoding',
            },
          ],
        },
      ],
    };

    const mockDetailThread = new DetailThread({
      id: 'thread-123',
      title: 'sebuah thread',
      body: 'sebuah body thread',
      date: '2021-08-08T07:22:33.555Z',
      username: 'dicoding',
    });

    const mockDetailComment = [
      {
        id: 'comment-123',
        username: 'dicoding',
        date: '2021-08-10T07:59:57.000Z',
        content: 'sebuah comment',
        is_deleted: true,
      },
    ];

    const mockDetailReply = [
      {
        id: 'reply-123',
        content: 'sebuah reply',
        date: '2021-08-11T07:59:57.000Z',
        username: 'dicoding',
        is_deleted: true,
        comment_id: 'comment-123',
      },
    ];

    const mockThreadRepository = new ThreadRepository();
    const mockCommentRepository = new CommentRepository();
    const mockReplyRepository = new ReplyRepository();

    mockThreadRepository.getThreadById = jest.fn()
      .mockImplementation(() => Promise.resolve(mockDetailThread));
    mockCommentRepository.getAllCommentsByThreadId = jest.fn()
      .mockImplementation(() => Promise.resolve(mockDetailComment));
    mockReplyRepository.getAllRepliesByThreadId = jest.fn()
      .mockImplementation(() => Promise.resolve(mockDetailReply));
    
    const getThreadUseCase = new DetailThreadUseCase({
      threadRepository: mockThreadRepository,
      commentRepository: mockCommentRepository,
      replyRepository: mockReplyRepository,
    });

    // Action
    const detailThread = await getThreadUseCase.execute(id);

    // Assert
    expect(detailThread).toStrictEqual(mockResult);
    expect(mockThreadRepository.getThreadById)
      .toBeCalledWith(id);
    expect(mockCommentRepository.getAllCommentsByThreadId)
      .toBeCalledWith(id);
    expect(mockReplyRepository.getAllRepliesByThreadId)
      .toBeCalledWith(id);
  });
});